<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php
$p=$_POST["uname"];
$q=$_POST["uemail"];
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'goyalnimish2864@gmail.com';                 // SMTP username
    $mail->Password = 'a2t8n6g4a2t8n6g4';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('welcome@bitsandbytes.com', 'Bits And Bytes');
    $mail->addAddress($q,$p);     // Add a recipient
    //$mail->addAddress('$a');               // Name is optional
    $mail->addReplyTo('no-reply@bitsandbytes.com', 'No-Reply');

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Welcome to BnB';
    $mail->Body    = 'Hi,'.$p.'welcome to Bits And Bytes.Get ready to Dive In the Ocean Of Knowledge. Always updated with us<br>-Team Bits And Bytes';
    $mail->AltBody = 'Hi,'.$p.'welcome to Bits And Bytes.Get ready to Dive In the Ocean Of Knowledge. Always updated with us-Team Bits And Bytes';

    $mail->send();
 {   
$a=$_POST['uname'];
$b=$_POST['uemail'];
$c=$_POST['umno'];
$d=$_POST['pwd'];
$e=$_POST['uadd1'];
$f=$_POST['uadd2'];
$g=$_POST['ucity'];
$h=$_POST['ustate'];
$i=$_POST['upin'];
$servername="localhost";
$username="root";
$password="";
$dbname="bits and bytes";

$conn=mysqli_connect($servername,$username,$password,$dbname);
                if ($conn) 
                {
                    $sql="INSERT INTO `user`(`type`, `name`, `email`, `mobileno`, `password`, `address1`, `address2`, `city`, `state`, `pincode`) VALUES ('client','$a','$b','$c','$d','$e','$f','$g','$h','$i')";
                    if (mysqli_query($conn,$sql)) 
                    {               
                                    session_start();   
                                    $_SESSION["NAME"]=$a;
                                    $_SESSION["EMAIL"]=$b;
                                    $_SESSION["TYPE"]="client";
                                    $_SESSION["MNO"]=$c;$_SESSION["ADD1"]=$e;
                                    $_SESSION["ADD2"]=$f;$_SESSION["CITY"]=$g;
                                    $_SESSION["STATE"]=$h;$_SESSION["PIN"]=$i;
                        }
                    }
    echo '<script>window.location.assign("../index.php");</script>';}
} catch (Exception $e) {
   echo '<script>alert("Cannot signup at this time please try again later");</script>'; 
   echo '<script>window.location.assign("../signup.php");</script>';
   //echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>
</body>
</html>