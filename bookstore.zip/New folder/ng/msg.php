<?php
$a=$_POST['mno'];
$a=$_POST['msg'];
$mobile="$a";
$message="$b";
$json = json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=xxxxxxxxxx&Password=xxxxxx&Message=".urlencode($message)."&To=".urlencode($mobile)."&Key=goyal3nYW7TMiBN6GdjHt6OlQlLXU"),true);
if ($json["status"]==="success") {
    echo $json["msg"];
    //your code when send success
}else{
    echo $json["msg"];
    //your code when not send
}
?>
 