<?php 
session_start();
if ($_SESSION["TYPE"]=="admin") {
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bits And Bytes.com</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style type="text/css">
	.bookname
	{
		font-size: 18px;
	}

	.bookprice
	{
		font-size: 20px;
	}
</style>
</head>
<body>
<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand"><b>Bits and Bytes</b>-Admin</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="users.php">Users</a></li>
				<li><a href="allbooks.php">All Book</a></li>
				<li><a href="usedbooks.php">Used Books request</a></li>
				<li><a href="contact.php">Contact Request</a></li>
				<li><a href="chart.php">Chart</a></li>
			</ul>
			<?php 
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">

				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle"><b class="caret"></b>Hi, <?php echo $_SESSION["NAME"]; ?></a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="profile.php?value=details">My Account</a></li>
						<li><a href="profile.php?value=editdetail">Edit Profile</a></li>					
						<li><a href="cart.php">Your Cart</a></li>
						<li><a href="profile.php?value=orders">Your Orders</a></li>
						<li><a href="profile.php?value=chngpassword">Change Password</a></li>
					</ul>
				</li>
				<?php if (!empty($_SESSION["NAME"])&&($_SESSION["TYPE"]=="admin")) {?>
					<li><a href="admin.php">Admin</a></li>
				<?php}?>
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				} }
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li><a href="cart.php">Cart</a></li>
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php }?>
			</div>
		</div>
	</div><br><br><br>
	<div class="container">
	<div class="row well">
			<?php 
$servername="localhost";
$username="root";
$password="";
$dbname="bits and bytes";

$conn=mysqli_connect($servername,$username,$password,$dbname);
	$sql="select * FROM usedbooks order by id desc";
    $result=mysqli_query($conn,$sql);
    if (mysqli_num_rows($result)>0)
	{ $i=1;
		?>
			<table border="2" style="width: 100%">
				<tr>
					<th colspan="10"><center><b>Users</b></center></th>
				</tr>
				<tr>
					<th><b>S. No.</b></th>
					<th><b>OwnerName</b></th>
					<th><b>Email</b></th>
					<th><b>Mobile NO.</b></th>
					<th><b>Address</b></th>
					<th><b>Book Name</b></th>
					<th><b>Publication</b></th>
					<th><b>Year of purchase</b></th>
					<th><b>Edition</b></th>
					<th><b>Author</b></th>
					<th><b>Expected Price</b></th>
					<th><b>Review</b></th>
				</tr>
		<?php while($row=mysqli_fetch_assoc($result)) {
				?>
				<tr>
					<th><?php echo $i; ?></th>
					<th><?php echo $row["oname"]; ?></th>
					<th><?php echo $row["oemail"]; ?></th>
					<th><?php echo $row["omobileno"]; ?></th>
					<th><?php echo $row["oaddress"]; ?></th>
					<th><?php echo $row["name"]; ?>	</th>
					<th><?php echo $row["publication"]; ?></th>
					<th><?php echo $row["yp"]; ?></th>
					<th><?php echo $row["edition"];?></th>
					<th><?php echo $row["author"]; ?></th>
					<th><?php echo $row["review"]; ?></th>
				</tr>
		<?php
		$i++;}
	} else{
		echo "<script>
	alert('No requests');window.location.assign('admin.php');
</script>";
	} 
	?>
</table>
	</div>
</div>
<?php }
else{
	echo "<script>window.location.assign('index.php')";
} 
 ?>
</div>
</body>
</html>