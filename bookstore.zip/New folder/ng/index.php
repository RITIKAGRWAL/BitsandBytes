<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bits And Bytes.com</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style type="text/css">
	.bookname
	{
		font-size: 18px;
	}

	.bookprice
	{
		font-size: 20px;
	}
</style>
</head>
<body>
<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand" style="color:white;">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thriller">Thrill</a></li>
					</ul>
				</li>
				<li><a href="all_books.php">All Book</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="sell_book.php">Sell A Book</a></li>
						<li><a href="buy_book.php">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.php">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<?php 
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">

				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle"><b class="caret"></b>Hi, <?php echo $_SESSION["NAME"]; ?></a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="profile.php?value=details">My Account</a></li>
						<li><a href="profile.php?value=editdetail">Edit Profile</a></li>					
						<li><a href="cart.php">Your Cart</a></li>
						<li><a href="orders.php">Your Orders</a></li>
						<li><a href="profile.php?value=chngpassword">Change Password</a></li>
					</ul>
				</li>
				<?php if (!empty($_SESSION["NAME"])&&($_SESSION["TYPE"]=="admin")) {?>
					<li><a href="admin.php">Admin</a></li>
				<?php } ?>
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				} 
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li><a href="cart.php">Cart</a></li>
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php }?>
			</div>
		</div>
	</div><br><br><br>
	<!--Close Row-->
	<div class="row">
		<div id="mycarousel" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="mycarousel" data-slide-to="0" class="active"></li>
				<li data-target="mycarousel" data-slide-to="1"></li>
				<li data-target="mycarousel" data-slide-to="2"></li>
				<li data-target="mycarousel" data-slide-to="3"></li>
			</ol>
			<div class="carousel-inner">
				<div class="item active"><img src="014.jpg" style="height:400px;width: 100%"></div>
				<div class="item"><img src="011.jpg" style="height:400px;width: 100%"></div>
				<div class="item"><img src="012.jpg" style="height:400px;width: 100%"></div>
				<div class="item"><img src="013.jpg" style="height:400px;width: 100%"></div>
			</div>
			<a href="#mycarousel" class="left carousel-control" data-slide="prev">
				<span class="glyphicon glyphicon-cheveron-left"></span>
				<span class="sr-only">previous</span>
			</a>
			<a href="#mycarousel" class="right carousel-control" data-slide="next">
				<span class="glyphicon glyphicon-cheveron-right"></span>
				<span class="sr-only">next</span>
			</a>
		</div>
	</div><br><br>
	<!--Close Row-->
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-heading" style="font-size: 25px;">Fresh Arrival</div>
		<div class="panel-body">
			      <?php $i=0;
						$conn=mysqli_connect("localhost","root","","bits and bytes");
						$sql="select * from books order by id desc";
						$result=mysqli_query($conn,$sql);
					if (mysqli_num_rows($result)) {
						while (($row=mysqli_fetch_assoc($result))&&($i<6)) {
					?>
			<div class="col-md-2"><center><img src="images/<?php echo $row["image"]; ?>" class="img-thumbnail" style="height: 200px;
			width:150px;"><br><span class="bookname"><?php echo $row["name"]; ?></span><br><span class="bookprice">Rs.<?php echo $row["price"]; ?>/-</span><br><a href="view_details.php?b_id=<?php echo $row["id"];?>"><button class="btn btn-success">View Details</button></a></center></div>
			<?php $i=$i+1;}}
			?>
			</div>
	</div>
	</div>
	<!--Close Row-->
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-heading" style="font-size: 25px;">Best seller</div>
		<div class="panel-body">
			 <?php $i=0;
						$conn=mysqli_connect("localhost","root","","bits and bytes");
						$sql="select * from books";
						$result=mysqli_query($conn,$sql);
					if (mysqli_num_rows($result)) {
						while (($row=mysqli_fetch_assoc($result))&&($i<6)) {
					?>
			<div class="col-md-2"><center><img src="images/<?php echo $row["image"]; ?>" class="img-thumbnail" style="height: 200px;
			width:150px;"><br><span class="bookname"><?php echo $row["name"];?></span><br><span class="bookprice">Rs.<?php echo $row["price"]; ?>/-</span><br>	<button class="btn btn-success">View Details</button></center></div>
			<?php $i=$i+1; }}
			?>
		</div>
	</div>
	</div>
		<!--Close Row-->
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-heading" style="font-size: 25px;">Authors</div>
		<div class="panel-body">
			 <?php $i=0;
						$conn=mysqli_connect("localhost","root","","bits and bytes");
						$sql="select * from books";
						$result=mysqli_query($conn,$sql);
					if (mysqli_num_rows($result)>0) {
						while (($row=mysqli_fetch_assoc($result))&&($i<6)) {
					?>
			<div class="col-md-2"><center><img src="images/<?php echo $row["image"].".jpg";?>" class="img-thumbnail" style="height: 200px;
			width:150px;"><br><span class="bookname"><?php echo $row["name"]; ?></span><br><span class="bookprice">Rs.<?php echo $row["price"]; ?>/-</span><br>	<button class="btn btn-success">View Details</button></center></div>
			<?php $i=$i+1; }}
			?>
		</div>
	</div>
	</div>
		<div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
			</div>
	<!--Code Above-->
</div>
</body>
</html>