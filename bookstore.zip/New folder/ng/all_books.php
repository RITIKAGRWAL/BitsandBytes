<?php 
session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Bis And Bytes.com</title><link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>

<div class="container-fluid">
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thrill">Thrill</a></li>
					</ul>
				</li>
				<li class="active"><a href="all_books.php">All Books</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu">
						<li><a href="sell_book.php">Sell A Book</a></li>
						<li><a href="buy_book.php">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.php">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<?php 
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle"><b class="caret"></b>Hi, <?php echo $_SESSION["NAME"]; ?></a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="profile.php?value=details">My Account</a></li>
						<li><a href="profile.php?value=editdetail">Edit Profile</a></li>					
						<li><a href="cart.php">Your Cart</a></li>
						<li><a href="orders.php">Your Orders</a></li>
						<li><a href="profile.php?value=chngpassword">Change Password</a></li>
					</ul>
				</li>
				
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				} 
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li><a href="cart.php">Cart</a></li>
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php } ?>
		</div></div>
	</div><br><br><br>
	
	<div class="container">	
			
			<div class="row">
						<?php
						$conn=mysqli_connect("localhost","root","","bits and bytes");
						$sql="select * from books";
						$result=mysqli_query($conn,$sql);

					if (mysqli_num_rows($result)) {     while
					($row=mysqli_fetch_assoc($result)) { ?>
					 <div class="col-md-6"><div class="panel panel-primary" style="box-shadow: 0px 10px 15px;">        
					  <div class="panel-body">
					<div class="col-md-4">  <center>
					<img src="images/<?php echo $row["image"]; ?>" class="img-responsive" style="height: 200px; width: 200px;">
					</center>     </div>     <div class="col-md-8"><b>
					<span class="text-default" style="font-size: 25px;">
					 <?php
					echo $row["name"]; ?> <br><span class="text-info" style="font-size: 14px;">Author:<?php  echo $row["author"];?>
					</span><br><span class="text-info" style="font-size:
					14px;">Categories: <?php  echo $row["categories"];?>
					</span><br><span class="text-info" style="font-size:
					14px;">Language:<?php  echo
					$row["language"];?></span><br><span class="text-info"
					style="font-size: 14px;">Publisher:<?php  echo
					$row["publication"];?></span></span><br></b>
					</div></div>     <div class="panel-footer">             <a
					href="view_details.php?b_id=<?php echo
					$row["id"];?>"><button class="btn btn-info">View
					Details</button></a>             <span class="text-danger"
					style="float: right;font-size: 30px;">RS. <?php  echo
					$row["price"];?>/-</span></div>
								
							</div>
						</div><?php }
					}	 ?>
					</div>
				</div>
				<!--code avobe-->
				<div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
			</div>
		</div></div>
</div>
</body>
</html>