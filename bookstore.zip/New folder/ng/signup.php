<?php 
session_start();
if (!empty($_SESSION["NAME"])) {
	header('location:index.php');
}
	else
	{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign Up- Bits And Bytes</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">
	function check() {
		var x=document.getElementById('p1').value;
		var y=document.getElementById('p2').value;
		if (x!=y) {
			alert("Password Didn't Match.s");
			return false;
		}
		{
		var username = document.getElementById('username').value;
		
			if(username ==""){
				alert("Enter Username");
			return false;
		}
		if((username.length <=2) || (username.length> 30)){
			alert("Enter Username");
			return false;
		}
		if(!isNaN(username)){
			alert("Enter Username");
			return false;
}
}
{
        var email = document.getElementById('email').value;
		
		if(email ==""){
			alert("Please enter email");
			return false;
		}
           	var number= document.getElementById('mobilenumber').value;
			
			if( number==""){
				alert("Please Enter Mobile Number");
			return false;
		}
           if(isNaN(number)){
           	alert("Please Enter Mobile Number");
			return false;
		}
		if(number.length!=10){
			alert("Please enter Valid Mobile Number");
					return false;
		}
}
	{	var a = document.getElementById('a1').value;
			if(a ==""){
				alert("Enter Address Line 1");
			return false;
		}
		if((a.length <=2) || (a.length> 30)){
			alert("Enter Address Line 1");
			return false;
		}
		if(!isNaN(a)){
			alert("Enter Address Line 1");
			return false;
        }

        var b = document.getElementById('a2').value;
			if(b ==""){
				alert("Enter Address Line 2");
			return false;
		}
		if((b.length <=2) || (b> 30)){
			alert("Enter Address Line 2");
			return false;
		}
		if(!isNaN(b)){
			alert("Enter Address Line 2");
			return false;
        }
}
{		var c = document.getElementById('a3').value;
		if(c ==""){
			alert("Enter City");
			return false;
		}
		if((c.length <=2) || (c> 30)){
			alert("Enter valid City");
			return false;
		}
		if(!isNaN(c)){
			alert("Enter valid City");
			return false;
        }
		var d = document.getElementById('a4').value;
		if( d==""){
				alert("Please Enter Pincode");
			return false;
		}
           if(isNaN(d)){
           	alert("Please Enter Pincode");
			return false;
		}
		if(d.length!=6){
			alert("Please enter Valid Pincode");
					return false;
		}
	}
	}

</script>

</head>
<body>
	<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a  class="navbar-brand" style="color: white">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thrill">Thrill</a></li>
					</ul>
				</li>
				<li><a href="all_books.php">All Books</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="sell_book.php">Sell A Book</a></li>
						<li><a href="buy_book.php">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.html">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="#">SIGNUP</a></li>
				</ul>
			</div>
		</div>
	</div><br><br><br><br>
	<div class="container">
       <center><div class="panel panel-primary"">
                  <div class="panel-heading" style="font-size: 30px;">Sign Up</div>
                  <div class="panel-body">
                 <div class="row">
                 	<form action="mail/mail.php" method="post" onsubmit="return check()">
                 	<div class="col-md-6 form-group">
                 		<label for="usr">Name</label>
                 		<input type="name" id="username" class="form-control" name="uname" required>
                 		<label>E-mail</label>
                 		<input type="email" id="email" class="form-control"  name="uemail" required>
                 		<label>Mobile No.</label>
                 		<input type="text" id="mobilenumber" class="form-control" maxlength="10" minlength="10"  name="umno" required>
                 		<label>Password</label>
                 		<input type="password" class="form-control"  name="pwd" id="p1" minlength="6" maxlength="8" required>
                 		<label>Re-Enter Password</label>
                 		<input type="password" class="form-control"  name="pwd2" id="p2" minlength="6" maxlength="8" required>
                 	</div>
                 	<div class="col-md-6">
                 		<label>Address line 1</label>
                 		<input type="text" class="form-control" id="a1" name="uadd1" required>
                 		<label>Address line 2</label>
                 		<input type="text" class="form-control" id="a2" name="uadd2" required>
                 		<label>city</label>
                 		<input type="text" class="form-control" id="a3" name="ucity" required>
                 		<label>state</label>
                 			<select name="ustate" class="form-control" required>
   		<option>Selelct-state*</option>
   		<option>Andhra Pradesh</option>
<option>Arunachal Pradesh</option>
<option>Assam</option>
(Dispur)
<option>Bihar</option>
(Patna)
<option>Chhattisgarh</option>
(Raipur)
<option>Goa</option>
(Panaji)
<option>Gujarat</option>
(Gandhinagar)
<option>Haryana</option>
(Chandigarh)
<option>Himachal Pradesh</option>
(Shimla)
<option>Jammu & Kashmir</option>
(Srinagar-S*, Jammu-W*)
<option>Jharkhand</option>
(Ranchi)
<option>Karnataka</option>
(Bangalore)
<option>Kerala</option>
(Thiruvananthapuram)
<option>Madhya Pradesh</option>
(Bhopal)
<option>Maharashtra</option>
(Mumbai)
<option>Manipur</option>
(Imphal)
<option>Meghalaya</option>
(Shillong)
<option>Mizoram</option>
(Aizawl)
<option>Nagaland</option>
(Kohima)
<option>Odisha</option>
(Bhubaneshwar)
<option>Punjab</option>
(Chandigarh)
<option>Rajasthan</option>
(Jaipur)
<option>Sikkim</option>
(Gangtok)
<option>Tamil Nadu</option>
(Chennai)
<option>Telangana</option>
(Hyderabad)
<option>Tripura</option>
(Agartala)
<option>Uttarakhand</option>
(Dehradun)
<option>Uttar Pradesh</option>
(Lucknow)
<option>West Bengal</option>
   		
   	</select>
                 		<label>Pincode</label>
                 		<input type="text" class="form-control" id="a4" maxlength="6" minlength="6"  name="upin" required>
                 	</div>
              
                 	</div>
                 </div>
                  <div class="panel-footer">
                        <input type="submit" name="submit" class="btn btn-success">&nbsp&nbsp<input type="reset" class="btn btn-danger">
                       </div>
                  </div></form>
 				</center>
 			</div>
        <br>
                 <?php		}
?>
                       
	<div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
				</div>
			</div>
</body>
</html>