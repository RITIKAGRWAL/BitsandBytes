<!DOCTYPE html>
<html>
<head>
	<title>Bits And Bytes.com</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<style type="text/css">
	.bookname
	{
		font-size: 18px;
	}

	.bookprice
	{
		font-size: 20px;
	}
</style>
</head>
<body>
<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand" style="color:white;">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thriller">Thrill</a></li>
					</ul>
				</li>
				<li><a href="all_books.php">All Book</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="sell_book.php">Sell A Book</a></li>
						<li><a href="buy_book.php">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.php">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<?php 
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">

				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle"><b class="caret"></b>Hi, <?php echo $_SESSION["NAME"]; ?></a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="profile.php?value=details">My Account</a></li>
						<li><a href="profile.php?value=editdetail">Edit Profile</a></li>					
						<li><a href="cart.php">Your Cart</a></li>
						<li><a href="orders.php">Your Orders</a></li>
						<li><a href="profile.php?value=chngpassword">Change Password</a></li>
					</ul>
				</li>
				<?php if (!empty($_SESSION["NAME"])&&($_SESSION["TYPE"]=="admin")) {?>
					<li><a href="admin.php">Admin</a></li>
				<?php } ?>
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				} 
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li><a href="cart.php">Cart</a></li>
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php }?>
			</div>
		</div>
	</div><br><br><br>
<?php 
session_start();
if ($_SESSION["TYPE"]=="admin") {
    ?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Statics', ''],
          ['No of Users', 5],
          ['No of Books', 14]
        ]);

        var options = {
          chart: {
            title: 'Bits And Bytes',
            subtitle: 'No of Users, No of Books',
          },
          bars: 'horizontal' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="barchart_material" style="width: 900px; height: 500px;"></div>
  </body>
</html>
<?php
}
else{
    header('location:index.php');
}
?>
    <div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
			</div>
	<!--Code Above-->
</div>
</body>
</html>