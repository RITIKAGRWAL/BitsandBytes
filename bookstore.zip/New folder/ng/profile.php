<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Bits And Bytes.com</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style type="text/css">
	.bookname
	{
		font-size: 18px;
	}

	.bookprice
	{
		font-size: 20px;
	}
	td{ 
		border:none;
		font-size: 20px;
		font-weight: bold;
		padding: 10px 14px;
		border-bottom: 1px dotted;
	}
	td:nth-child(even){
		background-color: grey;
	}
</style>
<script type="text/javascript">
	function check() {
		var x=document.getElementById('p1').value;
		var y=document.getElementById('p2').value;
		if (x!=y) {
			alert("Password Didn't Match");
			return false;
		}
	}

</script>
</head>
<body>
<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand" style="color:white;">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thrill">Thrill</a></li>
					</ul>
				</li>
				<li><a href="all_books.php">All Book</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="sell_book.php">Sell A Book</a></li>
						<li><a href="buy_book.php">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.php">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<?php 
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Hi, <?php echo $_SESSION["NAME"]; ?></a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="profile.php?value=details">My Account</a></li>
						<li><a href="profile.php?value=editdetail">Edit Profile</a></li>					
						<li><a href="cart.php">Your Cart</a></li>
						<li><a href="profile.php?value=orders">Your Orders</a></li>
						<li><a href="profile.php?value=chngpassword">Change Password</a></li>
					</ul>
				</li>
				<?php if (!empty($_SESSION["NAME"])&&($_SESSION["TYPE"]=="admin")) {?>
					<li><a href="admin.php">Admin</a></li>
				<?php } ?>
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				}
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li><a href="cart.php">Cart</a></li>
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php } ?>
			</div>
		</div>
	</div><br><br><br><br><br><br>
	<!--Close Row-->
<?php
if(isset($_GET['value']))
{
$value=$_GET['value']; 
$conn=mysqli_connect("localhost","root","","bits and bytes");
	
	if ($value=="details") {
		$user=$_SESSION["EMAIL"];
		$sql="select * from user where email='$user'";
		$result=mysqli_query($conn,$sql);
		if(mysqli_num_rows($result)){
			$row=mysqli_fetch_assoc($result); ?>
	<div class="panel panel-info">
		<div class="panel-heading">My Details</div>
		<div class="panel-body">
			<table class="container" border="1">
				<tr>
					<td>
						<span>Name</span><span style="float: right;"><?php echo $row["name"]; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						E-mail<span style="float: right;"><?php echo $row["email"]; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						Mobile No.<span style="float: right;"><?php echo $row["mobileno"]; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						Address Line 1<span style="float: right;"><?php echo $row["address1"]; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						Address Line 2<span style="float: right;"><?php echo $row["address2"]; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						City<span style="float: right;"><?php echo $row["city"]; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						State<span style="float: right;"><?php echo $row["state"]; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						Pincode <span style="float: right;"><?php echo $row["pincode"]; ?></span>
					</td>
				</tr>
			</table>
		</div>

	</div>
	<?php }
		}
 	else if ($value=="editdetail") {
		$user=$_SESSION["EMAIL"];
		$sql="select * from user where email='$user'";
		$result=mysqli_query($conn,$sql);
		if(mysqli_num_rows($result)){
			$row=mysqli_fetch_assoc($result); ?>
	<div class="panel panel-info">
		<div class="panel-heading">My Details</div>
		<div class="panel-body">
			<form method="post" onsubmit="return check()">
                 	<div class="col-md-6 form-group">
                 		<label for="usr">Name</label>
                 		<input type="name" class="form-control" value="<?php echo $_SESSION["NAME"]; ?>" name="uname" required>
                 		<label>E-mail</label>
                 		<input type="email" class="form-control" value="<?php echo $_SESSION["EMAIL"]; ?>"  name="uemail" required>
                 		<label>Mobile No.</label>
                 		<input type="text" class="form-control" maxlength="10" minlength="10" value="<?php echo $_SESSION["MNO"]; ?>"  name="umno" required>
                 		<label>Address line 1</label>
                 		<input type="text" class="form-control"  name="uadd1" value="<?php echo $_SESSION["ADD1"]; ?>" required>
                 	</div>
                 	<div class="col-md-6">
                 		
                 		<label>Address line 2</label>
                 		<input type="text" class="form-control"  name="uadd2" value="<?php echo $_SESSION["ADD2"]; ?>" required>
                 		<label>city</label>
                 		<input type="text" class="form-control"  name="ucity" value="<?php echo $_SESSION["CITY"]; ?>" required>
                 		<label>state</label>
                 			<select name="ustate" class="form-control">
   		<option><?php echo $_SESSION["STATE"]; ?></option>
   		<option>Andhra Pradesh</option>
<option>Arunachal Pradesh</option>
<option>Assam</option>
(Dispur)
<option>Bihar</option>
(Patna)
<option>Chhattisgarh</option>
(Raipur)
<option>Goa</option>
(Panaji)
<option>Gujarat</option>
(Gandhinagar)
<option>Haryana</option>
(Chandigarh)
<option>Himachal Pradesh</option>
(Shimla)
<option>Jammu & Kashmir</option>
(Srinagar-S*, Jammu-W*)
<option>Jharkhand</option>
(Ranchi)
<option>Karnataka</option>
(Bangalore)
<option>Kerala</option>
(Thiruvananthapuram)
<option>Madhya Pradesh</option>
(Bhopal)
<option>Maharashtra</option>
(Mumbai)
<option>Manipur</option>
(Imphal)
<option>Meghalaya</option>
(Shillong)
<option>Mizoram</option>
(Aizawl)
<option>Nagaland</option>
(Kohima)
<option>Odisha</option>
(Bhubaneshwar)
<option>Punjab</option>
(Chandigarh)
<option>Rajasthan</option>
(Jaipur)
<option>Sikkim</option>
(Gangtok)
<option>Tamil Nadu</option>
(Chennai)
<option>Telangana</option>
(Hyderabad)
<option>Tripura</option>
(Agartala)
<option>Uttarakhand</option>
(Dehradun)
<option>Uttar Pradesh</option>
(Lucknow)
<option>West Bengal</option>
   	</select>
                 		<label>Pincode</label>
                 		<input type="text" class="form-control" maxlength="6" minlength="6" value="<?php echo $_SESSION["PIN"]; ?>"  name="upin" required>
                 	</div>
              
                 	</div>
                 </div>
                  <div class="panel-footer">
                        <input type="submit" name="submit" class="btn btn-success">&nbsp&nbsp<input type="reset" class="btn btn-danger">
                       </div>
                  </div>   </form>
	</div>
	<?php
}
				if (isset($_POST['submit'])) {
					
					$userid=$_SESSION["EMAIL"];
					$a=$_POST['uname'];
					$b=$_POST['uemail'];
					$c=$_POST['umno'];
					$e=$_POST['uadd1'];
					$f=$_POST['uadd2'];
					$g=$_POST['ucity'];
					$h=$_POST['ustate'];
					$i=$_POST['upin'];
					$sqli="UPDATE `user` SET `name`='$a',`email`='$b',`mobileno`='$c',`address1`='$e',`address2`='$f',`city`='$g',`state`='$h',`pincode`='$i' WHERE email='$userid'";
					if (mysqli_query($conn,$sqli)) 
						{
   					  $_SESSION["NAME"]=$a;$_SESSION["EMAIL"]=$b;
					  $_SESSION["MNO"]=$c;$_SESSION["ADD1"]=$e;
					  $_SESSION["ADD2"]=$f;$_SESSION["CITY"]=$g;
				      $_SESSION["STATE"]=$h;$_SESSION["PIN"]=$i;?>
						<script type="text/javascript">
							alert("Your Profile Has Been Updated");
							window.location.assign('profile.php?value=details');
						</script>
					<?php }
					else{
						echo "Not Updated";
					}
				}
			}
				else if ($value=="chngpassword") { ?>
			<div class="container" style="width:300px;">
	<form method="post">
       <center><div class="panel panel-primary" id="fp">
                  <div class="panel-heading">Forgot Password</div>
                  <div class="panel-body form-group">
                  	<form method="post" action="forgot_password.php">
                  		<input type="password" id="p" name="pwd" class="form-control"><br>
                  		<input type="password" id="pn" name="p" class="form-control"><br>
                  		<input type="submit" name="cp" value="submit" class="btn btn-success form-control">
                  	</form>
                  </div></div>
                  </div></form></div>
 				</center>
			<?php	
			if (isset($_POST['cp'])) {
				$userid=$_SESSION["EMAIL"];
					$a=$_POST['pwd'];
				$sqli="UPDATE `user` SET `password`='$a' WHERE email='$userid'";
				if (mysqli_query($conn,$sqli)) {
						?>
						<script type="text/javascript">
							alert("Your Password Has Been Updated");
							window.location.assign('profile.php?value=details');
						</script>
					<?php
				}
			}
			}
		}
 ?>

<div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
				</div>
</div>
</div>
</body>
</html>