<?php  
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bis And Bytes.com</title><link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>

<div class="container-fluid">
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.html" class="navbar-brand">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thrill">Thrill</a></li>
					</ul>
				</li>
				<li><a href="all_books.php">All Books</a></li>
				<li class="dropdown active"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu">
					<li><a href="sell_book.php">Sell A Book</a></li>
						<li><a href="buy_book.php">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.php">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<?php 
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li><a href="#">Hi, <?php echo $_SESSION["NAME"]; ?></a></li>
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				} 
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php } ?>
		</div>
	</div><br><br><br>
	<!--Close Row-->
	<div class="row">
		<div id="mycarousel" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="mycarousel" data-slide-to="0" class="active"></li>
				<li data-target="mycarousel" data-slide-to="1"></li>
				<li data-target="mycarousel" data-slide-to="2"></li>
				<li data-target="mycarousel" data-slide-to="3"></li>
			</ol>
			<div class="carousel-inner">
				<div class="item active"><img src="014.jpg"  style="height: 500px;width: 100%"></div>
				<div class="item"><img src="011.jpg" style="height: 500px;width: 100%"></div>
				<div class="item"><img src="012.jpg" style="height: 500px;width: 100%"></div>
				<div class="item"><img src="013.jpg" style="height: 500px;width: 100%"></div>
			</div>
			<a href="#mycarousel" class="left carousel-control" data-slide="prev">
				<span class="glyphicon glyphicon-cheveron-left"></span>
				<span class="sr-only">previous</span>
			</a>
			<a href="#mycarousel" class="right carousel-control" data-slide="next">
				<span class="glyphicon glyphicon-cheveron-right"></span>
				<span class="sr-only">next</span>
			</a>
		</div></div>
	</div><br><br>
<!--close row-->
			<div class="container">
				<div class="row">
					<div class="panel panel-info form-group" style="float: center;">
						<div class="panel-heading">
							Sell Your Book Here
						</div>
						<div class="panel-body">
							<form method="post">
									<input type="text" class="form-control well" name="oname" required placeholder="Your Name"> 
									<input type="text" class="form-control well" name="omno" required placeholder=" Contact No.">
									<input type="email" class="form-control well" name="oemail" required placeholder="Your E-mail"><br>
									<input type="address" class="form-control well" name="oadd" required placeholder="Address">
						</div>
						<div class="panel-heading">
								Book Discription
						</div>
						<div class="panel-body">
								<div class="col-md-6">
									<input class="form-control well" type="text" name="ub_name" placeholder="Book Name">
									<input class="form-control well" type="text" name="ub_pub_name" placeholder="Publication Name">
									<input class="form-control well" type="number" max="20" min="0" name="ub_yr-of-purchase" placeholder="Year Of Purchasing">
									<input class="form-control well" type="number" max="50" min="0" name="ub_edition" placeholder="Edition">
									</div>
								<div class="col-md-6">
									<input class="form-control well" type="text" name="ub_author" placeholder="Author Name">
									<input class="form-control well" type="text" name="ub_ex_price" placeholder="Expected Price">
									<input class="form-control well" type="text" name="ub_review" placeholder="Review (If Any)">
									<input class="form-control" type="file" name="">
								</div>

						</div>
						<div class="panel-footer">
							<input type="reset" class="btn btn-warning" name="">
							<input type="submit" class="btn btn-success" name="sell" style="float: right;width: 200px;">
						</div>
					</form>
					</div>
				</div>
			</div>
		<?php 
			if(isset($_POST['sell']))
			{
				$a=$_POST['ub_name'];
				$b=$_POST['ub_pub_name'];
				$c=$_POST['ub_yr-of-purchase'];
				$d=$_POST['ub_edition'];
				$e=$_POST['ub_author'];
				$f=$_POST['ub_ex_price'];
				$g=$_POST['ub_review'];
				//$h=$_POST[''];
					$conn=mysqli_connect("localhost","root","","bits and bytes");
					if($conn){
				$sql="insert into usedbooks (`name`,`publication`,`yp`,`edition`,`author`,`price`,`review`) value ('$a','$b','$c','$d','$d','$e','$f','$g')";}
				else{?>
				<script type="text/javascript">
					alert("Database Can't Connect");
				</script>
				<?php 
				}
			 }

			 ?>
	<div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
			</div>

</div>
</body>
</html>