<?php
  session_start();
  include_once("src/Google_Client.php");
  include_once("src/contrib/Google_Oauth2Service.php");
  // Fill CLIENT ID, REDIRECT URI from Google Developer Console
  $client_id = '500234063763-ul7skho11nd54cg6lj5g4ro2t2iqvmfe.apps.googleusercontent.com';
  $client_secret = 'B5pSIqTFDjh_C31Qmviz_sfg';
  $redirect_uri = 'http://pizzakings.000webhostapp.com';

  //Create Client Request to access Google API
  $client = new Google_Client();
  $client->setClientID($client_id);
  $client->setClientSecret($client_secret);
  $client->setRedirectUri($redirect_uri);
  //$client->addScope("https://www.googleapis.com/auth/userinfo.email");

  //Send Client Request
  $objOAuthService = new Google_Oauth2Service($client);
  ?>