<?php 
	session_start();
	/*if (isset($_SESSION["shopping_cart"])) {
		$a=$_SESSION["EMAIL"];$b=json_encode($_SESSION["shopping_cart"]);
		$conn=mysqli_connect("localhost","root","","bits and bytes");
		if($conn){
		$sql="INSERT INTO `cart`(`email`,`productname`) VALUES ('$a','$b')";
		if(mysqli_query($conn,$sql)){
		echo "okk";}
		}
	}*/
	if (!empty($_SESSION["Google"])) {
		include 'googlelogin/logout.php';
	}
	
	session_unset();
	header('location: index.php');
 ?>