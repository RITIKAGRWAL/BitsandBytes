<?php 
session_start();
if ($_SESSION["TYPE"]=="admin") {
	$servername="localhost";
$username="root";
$password="";
$dbname="bits and bytes";

$conn=mysqli_connect($servername,$username,$password,$dbname);

	if (isset($_POST['add'])) {
		$file=$_FILES['bimage'];
		$dst="C:/xampp/htdocs/New folder/ng/images/".$_FILES['bimage']['name'];
		move_uploaded_file($_FILES['bimage']['tmp_name'], $dst);
$a=$_POST['bname'];
$b=$_POST['bisbnno'];
$c=$_FILES['bimage']['name'];
$d=$_POST['bcategories'];
$e=$_POST['bauthor'];
$f=$_POST['bpublication'];
$g=$_POST['bdiscription'];
$h=$_POST['blanguage'];
$i=$_POST['bedition'];
$j=$_POST['bgenre'];
$k=$_POST['bpublishdate'];
$l=$_POST['bpages'];
$m=$_POST['bprice'];
$n=$_POST['bquantity'];
$o=$_POST['bcode'];
	$sql="INSERT INTO `books`(`name`, `isbnno`, `image`, `categories`, `author`, `publication`, `discription`, `language`, `edition`, `genre`, `publishdate`, `pages`, `price`, `quantity`, `bookcode`) VALUES ('$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k','$l','$m','$n','$o')";
	if(mysqli_query($conn,$sql))
	{
		?>
<script>
	alert('Book Added');
</script>
<?php	}
else
	{
		?>
<script>
	alert('Book Already Exist');
</script>
<?php	}

	}

elseif ($_POST["delete"]) {
	$a=$_POST['bname'];
	$b=$_POST['bisbnno'];
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="bits and bytes";

$conn=mysqli_connect($servername,$username,$password,$dbname);

	$sql="select * FROM books WHERE name='$a'&& isbnno='$b'";
    $result=mysqli_query($conn,$sql);
    if (mysqli_num_rows($result)>0)
	{
			$row=mysqli_fetch_assoc($result);
	$del="delete FROM books WHERE name='$a'&& isbnno='$b'";
	if(mysqli_query($conn,$del))
		{
	echo "<script>
	alert('Book Deleted');
</script>";
		}
	else{
	echo "<script>
	alert('Book not Delete');
</script>";
		}
	}
	else{
		echo "<script>
	alert('Book Details Not Matched');
</script>";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bits And Bytes.com</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style type="text/css">
	.bookname
	{
		font-size: 18px;
	}

	.bookprice
	{
		font-size: 20px;
	}
</style>
</head>
<body>
<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand"><b>Bits and Bytes</b>-Admin</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="users.php">Users</a></li>
				<li><a href="allbooks.php">All Book</a></li>
				<li><a href="usedbooks.php">Used Books request</a></li>
				<li><a href="contact.php">Contact Request</a></li>
				<li><a href="chart.php">Chart</a></li>
			</ul>
			<?php
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">

				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle"><b class="caret"></b>Hi, <?php echo $_SESSION["NAME"]; ?></a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="profile.php?value=details">My Account</a></li>
						<li><a href="profile.php?value=editdetail">Edit Profile</a></li>					
						<li><a href="cart.php">Your Cart</a></li>
						<li><a href="orders.php">Your Orders</a></li>
						<li><a href="profile.php?value=chngpassword">Change Password</a></li>
					</ul>
				</li>
				<?php if (!empty($_SESSION["NAME"])&&($_SESSION["TYPE"]=="admin")) {?>
					<li><a href="admin.php">Admin</a></li>
				<?php}?>
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				} }
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li><a href="cart.php">Cart</a></li>
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php }?>
			</div>
		</div>
	</div><br><br><br>
	<div class="container">
	<div class="row well">
		<div class="form-group">
			<div class="col-sm-12 text-info" style="font-weight: bolder;"><center>Add A Book</center></div><br>
			<form action="admin.php" method="post" enctype="multipart/form-data">
				<div class="col-sm-6">
				<label>Book Name</label>
				<input type="text" name="bname" class="form-control">
				<label>Book Isbn No.</label>
				<input type="text" name="bisbnno" class="form-control">
				<label>Book Image file</label>
				<input type="file" name="bimage" class="form-control">
				<label>Book categories</label>
				<input type="text" name="bcategories" class="form-control">
				<label>Book Author</label>
				<input type="text" name="bauthor" class="form-control">
				<label>Book Publication Name</label>
				<input type="text" name="bpublication" class="form-control">
				<label>Book Discription</label>
				<input type="text" name="bdiscription" class="form-control">
				<label>Book Language</label>
				<input type="text" name="blanguage" class="form-control">
			</div>
			<div class="col-sm-6">
				<label>Book Edition</label>
				<input type="text" name="bedition" class="form-control">
				<label>Book Gener</label>
				<input type="text" name="bgenre" class="form-control">
				<label>Book Publish Date</label>
				<input type="text" name="bpublishdate" class="form-control">
				<label>Book Pages</label>
				<input type="text" name="bpages" class="form-control">
				<label>Book Price</label>
				<input type="text" name="bprice" class="form-control">
				<label>Book Quantity</label>
				<input type="text" name="bquantity" class="form-control">
				<label>Book Code</label>
				<input type="text" name="bcode" class="form-control"><br>
				<input type="submit" value="SUBMIT" name="add" class="btn btn-success form-control">
			</div>
			</form>
		</div>
	</div>
	<div class="row well">
		<div class="form-group">
			<div class="col-sm-12 text-info" style="font-weight: bolder;"><center>Delete Book</div><br>
			<form action="admin.php" method="post">
				<div class="col-sm-offset-3 col-sm-6">
				<label>Book Name</label>
				<input type="text" name="bname" class="form-control">
				<label>Book Isbn No.</label>
				<input type="text" name="bisbnno" class="form-control"><br>
				<input type="submit" value="SUBMIT" name="delete" class="btn btn-success form-control">
			</div>
			</form>
		</center>
		</div>
	</div>
	</div>
</div>
<?php }
else{
	echo "<script>window.location.assign('index.php')";
} 
 ?>