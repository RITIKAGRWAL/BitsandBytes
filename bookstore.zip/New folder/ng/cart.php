<?php
session_start();
$conn=mysqli_connect("localhost","root","","bits and bytes");
if (isset($_POST['delete'])) 
{
	foreach ($_SESSION["shopping_cart"] as $key => $value) {
		if ($value["productid"]==$_GET["remove"]) {
			unset($_SESSION["shopping_cart"][$key]);
			echo "<script>alert('Your Order Can't be Placed');</script>";
			echo "<script>window.location.assign('cart.php')</script>";
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bits And Bytes.com</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style type="text/css">
	.bookname
	{
		font-size: 18px;
	}

	.bookprice
	{
		font-size: 20px;
	}
	td{ 
		border:none;
		font-size: 20px;
		font-weight: bold;
		padding: 10px 14px;
		border-bottom: 1px dotted;
	}
	td:nth-child(even){
		background-color: grey;
	}
</style>
</head>
<body>
<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand" style="color:white;">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thriller">Thrill</a></li>
					</ul>
				</li>
				<li><a href="all_books.php">All Book</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="sell_book.php">Sell A Book</a></li>
						<li><a href="buy_book.php">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.php">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<?php 
				if (!empty($_SESSION["NAME"]))
				{
			 ?>
                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Hi, <?php echo $_SESSION["NAME"]; ?></a>
					<ul class="dropdown-menu" style="background-color:lightblue;">
						<li><a href="profile.php?value=details">My Account</a></li>
						<li><a href="profile.php?value=editdetail">Edit Profile</a></li>					
						<li><a href="cart.php">Your Cart</a></li>
						<li><a href="orders.php">Your Orders</a></li>
						<li><a href="profile.php?value=chngpassword">Change Password</a></li>
					</ul>
				</li>
				<li><a href="signout.php">LOGOUT</a></li>
                </ul>
				<?php
				} 
				else
				{
			 ?>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
				<?php } ?>
			</div>
		</div>
	</div><br><br><br>
	<!--Close Row-->
		<div class="panel panel-info">
				<div class="panel-heading">Your Cart</div>
				<div class="panel-body">
		<?php if(!empty($_SESSION["shopping_cart"]))
		{ 
			$total=0;	
				foreach ($_SESSION["shopping_cart"] as $key => $value) 
				{
				$total=$total+$value['productprice']*$value['productqty'];?>
					<div class="col-sm-4">		
				<div class="panel" style="background-color: white;border:none;">
					<div class="panel-heading" style="background-color:#CCCCFF"><?php echo $value['productname']; ?></div>
					<div class="panel-body">
					<div class="col-sm-6"><img src="images/<?php echo $value['productimage'];?>" style="height: 150px;width: 100px;" ></div>
					<div class="col-sm-6"><br><br><b>Qty.</b> <?php echo $value['productqty'];?><br><br><br><b>Price.</b> <?php echo $value['productprice'];?></div>
					</div>
					<div class="panel-footer">	
						<form action="cart.php?remove=<?php echo $value['productid'];?>" method="post"><input type="submit" name="delete" value="Remove" class="btn btn-danger"><span style="float: right;">Total: <?php echo $value['productqty']*$value['productprice'];?></span></form>
					</div>		
					</div>
				</div><?php } ?>
			</div>
		<div class="panel-footer">
			total= <?php echo $total;?>
			<form method="post">
			<input type="submit" name="checkout" value="Checkout" class="btn btn-success"></form>
		</div>
	</div><?php 
				if (isset($_POST['checkout']))
		    {

				if (!empty($_SESSION["EMAIL"]))
			    {
			    	$user=$_SESSION["EMAIL"];
			    	$order=json_encode($_SESSION["shopping_cart"]);
			    	$place="INSERT INTO `orders`(`email`, `orders`) VALUES ('$user','$order')";
			    	if (mysqli_query($conn,$place)) {
			    		echo "<script>alert('Your Oeder Has Been Succesfully Placed');</script>";
			    			unset($_SESSION["shopping_cart"]);		
			    			echo "<script>window.location.assign('cart.php')</script>";
			    	}
			    	else
			    	{echo "<script>alert('Your Order Can't be Placed');</script>";
					}
				}
				else
				{
					echo "<script>alert('Please login First');</script>";
				}

			}
} 
		else{?>
		<center>
				<br><br><b>No Items in your Cart</b><br><a href="index.php"><button class="btn btn-success">Continue Shopping</button></a><br>
			</div></div>
			</center>
		<?php }?>
				<div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
			</div>
	<!--Code Above-->
</body>
</html>		