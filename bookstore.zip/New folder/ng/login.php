<?php 
session_start();
if (!empty($_SESSION["NAME"])) {
	header('location:index.php');}
	else
	{
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>login page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid">
<!--Code Below-->
	<div class="row">
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="navbar-header">
				<a  class="navbar-brand" style="color: white">Bits and Bytes</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Categories<b class="caret"></b>
					</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="Categories.php?gener=action">Action</a></li>
						<li><a href="Categories.php?gener=education">Education</a></li>					
						<li><a href="Categories.php?gener=health">Health</a></li>
						<li><a href="Categories.php?gener=cooking">Cooking</a></li>
						<li><a href="Categories.php?gener=romance">Romance</a></li>
						<li><a href="Categories.php?gener=horror">Horror</a></li>
						<li><a href="Categories.php?gener=thrill">Thrill</a></li>
					</ul>
				</li>
				<li><a href="all_books.php">All Books</a></li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Used Books<b class="caret"></b>
				</a>
					<ul class="dropdown-menu" style="background-color: lightblue">
						<li><a href="#">Sell A Book</a></li>
						<li><a href="#">Buy A Book</a></li>
					</ul>
				</li>
				<li><a href="aboutus.html">About Us</a></li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
				<li class="acive"><a href="login.php">LOGIN</a></li>
				<li><a href="signup.php">SIGNUP</a></li>
				</ul>
			</div>
		</div>
	</div>
        <?php
//Include GP config file && User class
include_once 'gpConfig.php';
include_once 'User.php';

	
    //Authenticate code from Google OAuth Flow
  //Add Access Token To Session
  if (isset($_GET['code'])) {
    $client->authenticate($_GET['code']);
    $_SESSION['access_token'] = $client->getAccessToken();
    header('Location: '. filter_var($redirect_uri, FILTER_SANITIZE_URL));  
  }

  //Set Access Token to make Request
  if (isset($_SESSION['access_token'])&& $_SESSION['access_token']) {
    $client->setAccessToken($_SESSION['access_token']);
  }

  //Get User Data from Google Plus
  if ($client->getAccessToken()) {
    $gpUserProfile = $objOAuthService->userinfo->get();
    $_SESSION['access_token'] = $client->getAccessToken();
    //Initialize User class
	$user = new User();
	
	//Insert or update user data to the database
    $gpUserData = array(
        'oauth_provider'=> 'google',
        'oauth_uid'     => $gpUserProfile['id'],
        'first_name'    => $gpUserProfile['given_name'],
        'last_name'     => $gpUserProfile['family_name'],
        'email'         => $gpUserProfile['email'],
        'gender'        => $gpUserProfile['gender'],
        'locale'        => $gpUserProfile['locale'],
        'picture'       => $gpUserProfile['picture'],
        'link'          => $gpUserProfile['link']
    );
    $userData = $user->checkUser($gpUserData);
	
	//Storing user data into session
	$_SESSION['userData'] = $userData;
	
	//Render facebook profile data
    if(!empty($userData)){
        $output = '<h1>Google+ Profile Details </h1>';
        $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
        $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
        $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
        $output .= '<br/>Email : ' . $userData['email'];
        $output .= '<br/>Gender : ' . $userData['gender'];
        $output .= '<br/>Locale : ' . $userData['locale'];
        $output .= '<br/>Logged in with : Google';
        $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
        $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
        $_SESSION["NAME"]=$userData['first_name'];
    }else{
        $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
    }
} else {
	$authUrl = $client->createAuthUrl();
	$output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt="" style="width:40%;" /></a>';
}
?>
<div class="container" style="width:300px;margin-top:40px;">
	<form method="post">
       <center><div class="panel panel-primary">
                  <div class="panel-heading">Login</div>
                  <div class="panel-body form-group">
                 
                  <div><img src="images.jpg" style="height: 120px"></div>
                 
                  	 <font>Username</font>
                  	 <br>
                       <input type="text" name="email" placeholder="email*" class="form-control">
                        <br>
                        <br>
                        <font>Password</font>  
                        <br>
                        <input type="password" name="pwd" placeholder="password*" class="form-control">
                        <br>
                        <br>
                        <font style="">forget password 
                        <a href="forgot_password.php">click here</a></font>
                        <br>
                      <div><?php echo $output; ?></div>
                        <br>
                        <div class="panel-footer">
                        <input type="submit" name="submit" class="btn btn-success"> <a href="googlelogin/glogin.php"><button class="btn btn-danger">Google Login</button></a>
                    </form>

                    	<?php 
                           
                    		if (isset($_POST['submit'])) {
                                
                                 $a=$_POST['email'];
                                $b=$_POST['pwd'];
                                $servername="localhost";
                                $username="root";
                                $password="";
                                $dbname="bits and bytes";

                                $conn=mysqli_connect($servername,$username,$password,$dbname);
                    		  $sql="select * FROM user WHERE email='$a' && password='$b'";
                    		   	$result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result)){
                                    //session_start();
                                    $row=mysqli_fetch_assoc($result);
								    $_SESSION["NAME"]=$row['name'];$_SESSION["EMAIL"]=$row['email'];
								    $_SESSION["MNO"]=$row['mobileno'];$_SESSION["ADD1"]=$row['address1'];
								    $_SESSION["ADD2"]=$row['address2'];$_SESSION["CITY"]=$row['city'];
								    $_SESSION["STATE"]=$row['state'];$_SESSION["PIN"]=$row['pincode'];
                                    $_SESSION["TYPE"]=$row['type'];
                                    echo "<script>window.location.assign('index.php');</script>";
                    		   }
                                else
                                {
                            ?>
                            <script>
                                alert("wrong inputs")
                                </script>
                            <?php
                                }
                    		}

                    	}
                    	 ?>

                       </div></div>
                  </div></form></div>
 				</center>
        <br>
	<div class="row well" style="background-color: #0C0C0C;">	
			<div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
			<div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
			<div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
				&copy Bits And pvt. ltd.<br>Poornima institute of Engineering & Technology, <br>Sitapura Institutional Area,<br>Jaipur,<br> Rajasthan. <br>E-mail:-bitsandbytes@gmail.com <br>Contact No:- 8741894758,8949782691.
				</div>
			</div>
</body>
</html>